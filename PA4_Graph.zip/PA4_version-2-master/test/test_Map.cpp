/**
 * Authors: Yilan Jiang & Hongsheng Xie
 * Emails: yij007@ucsd.edu & hox012@ucsd.edu
 * This file contains some tests and test fixtures to
 * test all implements written in Map.cpp file.
 */

#include <gtest/gtest.h>
#include <Map.hpp>
using namespace std;
using namespace testing;

/* Test the method for Dijkstra Algorithm */
TEST(MAPtest, DIJKSTRA_TEST) {
    Map map;
    map.buildMapTest();
    vector<Vertex*> SP;
    map.Dijkstra("Warren", "Revelle", SP);
    ASSERT_EQ(SP[0]->name, "Warren");
    ASSERT_EQ(SP[1]->name, "CSE");
    ASSERT_EQ(SP[2]->name, "WarrenLectureHall");
    ASSERT_EQ(SP[3]->name, "PriceCenter");
    ASSERT_EQ(SP[4]->name, "Mandeville");
    ASSERT_EQ(SP[5]->name, "MainGym");
    ASSERT_EQ(SP[6]->name, "Revelle");
}

/* Test the method for MST Algorithm */
TEST(MAPtest, MST_TEST) {
    Map map;
    map.buildMapTest();
    vector<Edge*> MST;
    map.findMST(MST);
    ASSERT_EQ(MST[0]->source->name, "HopkinsParking");
    ASSERT_EQ(MST[1]->source->name, "SupercomputerCenter");
    ASSERT_EQ(MST[2]->source->name, "GalbraithHall");
}

/* Test the method for crucial path algorithm */
TEST(MAPtest, CRUCIAL_TEST) {
    Map map;
    map.buildMapTest();
    vector<Edge*> road;
    map.crucialRoads(road);
    ASSERT_EQ(road[0]->target->name, "BioMedLib");
    ASSERT_EQ(road[0]->source->name, "OslerParking");
    ASSERT_EQ(road[1]->source->name, "CSE");
    ASSERT_EQ(road[1]->target->name, "Warren");
}