/**
 * Authors: Yilan Jiang & Hongsheng Xie
 * Emails: yij007@ucsd.edu & hox012@ucsd.edu
 * This file contains testers to test ActorGraph.cpp
 * and ActorGraph.hpp.
 * */

#include <gtest/gtest.h>
#include <algorithm>
#include <string>
#include <utility>
#include <vector>

#include "ActorGraph.hpp"

using namespace std;
using namespace testing;

/*This test tests on the buildGraphFromFile method*/
TEST(ACTORGRAPHTest, BUILD_TEST) {
    ActorGraph ag;
    //call the buildGraphTest() which will call
    //buildGraphFromFile()
    ag.buildGraphTest();
    ASSERT_TRUE(ag.ActorSet.find("Kevin Bacon") != ag.ActorSet.end());
    Actor* act = ag.ActorSet.find("Michael Fassbender")->second;
    string mv = "X-Men: First Class#@" + to_string(2011);
    Movie* mov = ag.MovieSet.find(mv)->second;
}

//Test the BFS method
TEST(ACTORGRAPHTest, BFS_TEST) {
    ActorGraph ag;
    ag.buildGraphTest();
    string path = "";
    ag.BFS("Kevin Bacon", "Tom Holland", path);
    string ref =
        "(Kevin Bacon)--[X-Men: First Class#@2011]-->(Michael "
        "Fassbender)--[Alien: Covenant#@2017]-->(Katherine Waterston)--[The "
        "Current War#@2017]-->(Tom Holland)";
    ASSERT_EQ(ref, path);
}

//Test a more difficult BFS method
TEST(ACTORGRAPHTest, BFS_TEST_HARD) {
    ActorGraph ag;
    ag.buildGraphTest();
    string path = "";
    ag.BFS("Michael Fassbender", "Robert Downey Jr.", path);
    string ref =
        "(Michael Fassbender)--[X-Men: First Class#@2011]-->(James "
        "McAvoy)--[Glass#@2019]-->(Samuel L. Jackson)--[Avengers: "
        "Endgame#@2019]-->(Robert Downey Jr.)";
    ASSERT_EQ(ref, path);
    path = "";
    ag.BFS("Robert Downey Jr.", "Robert Downey Jr.", path);
    ASSERT_EQ("", path);
}

//Test the predictLink method
TEST(ACTORGRAPHTest, PREDICT_LINK_TEST) {
    ActorGraph ag;
    ag.buildGraphTest();
    vector<string> result;
    ag.predictLink("Kevin Bacon", result, 3);
    ASSERT_EQ(result[0], "Katherine Waterston");
    ASSERT_EQ(result.size(), 2);
}