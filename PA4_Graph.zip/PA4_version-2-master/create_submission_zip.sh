#!/usr/bin/env bash
zip submission.zip -r src test
